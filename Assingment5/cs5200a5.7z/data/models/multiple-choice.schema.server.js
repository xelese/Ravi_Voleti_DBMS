const mongoose = require('mongoose')

module.exports = mongoose.Schema({
                                     choices: String,
                                     correct: Number
                                 }, {collection: 'questions'});