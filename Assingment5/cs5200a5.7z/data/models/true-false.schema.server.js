const mongoose = require('mongoose');

module.exports = mongoose.Schema({
                                            isTrue: Boolean
                                        }, {collection: 'questions'});